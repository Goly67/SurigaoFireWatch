const { onSchedule } = require('firebase-functions/v2/scheduler');
const { defineSecret, defineString } = require('firebase-functions/params');
const { initializeApp } = require('firebase-admin/app');
const { getDatabase } = require('firebase-admin/database');

initializeApp();

/**
 * Only a Page you administer, not "every social media" and not Groups.
 *
 * Facebook closed keyword search across arbitrary public content in Graph
 * API v2.0 (2015) and never reopened it at any price. Reading a Group's feed
 * needs Meta's Groups API app-review approval, which can take weeks. Reading
 * your own Page's feed needs neither — just a Page Access Token — which is
 * why this polls a Page, e.g. a public "Surigao Fire Watch Reports" tip
 * line, rather than trying to watch the whole platform.
 *
 * Requires the Blaze (pay-as-you-go) plan. Firebase will not run *any*
 * Cloud Function, including this one, on the free Spark plan — that is a
 * platform rule, not a size limit. In practice a function this small stays
 * inside the free monthly quota and costs $0, but a billing account has to
 * be on the project for Google to let it run at all.
 */
const PAGE_ACCESS_TOKEN = defineSecret('FB_PAGE_ACCESS_TOKEN');
const PAGE_ID = defineString('FB_PAGE_ID');

// English, Filipino, and Bisaya/Surigaonon — match whichever a resident
// actually types. Keep this in sync with any client-side copy of the list.
const FIRE_KEYWORDS = [
  'fire', 'burning', 'flames', 'ablaze', 'smoke',
  'sunog', 'nasunog', 'nagsunog', 'sinunog',
  'kalayo', 'nagkalayo', 'gikalayo', 'gisunog',
];

function mentionsFire(text = '') {
  const lower = text.toLowerCase();
  return FIRE_KEYWORDS.some((kw) => lower.includes(kw));
}

/**
 * Best-effort barangay match so a located mention can enter the same
 * clustering/triage pipeline as an app report. A barangay list this small
 * is loaded inline rather than shared across the Vite app and this
 * CommonJS function package — keep it in sync with src/data/surigao.js.
 */
const BARANGAYS = [
  { id: 'washington', name: 'Washington', center: [9.7880, 125.4936] },
  { id: 'taft', name: 'Taft', center: [9.7852, 125.4907] },
  { id: 'luna', name: 'Luna', center: [9.7902, 125.4881] },
  { id: 'rizal', name: 'Rizal', center: [9.7826, 125.4948] },
  { id: 'san_juan', name: 'San Juan', center: [9.7774, 125.4890] },
  { id: 'canlanipa', name: 'Canlanipa', center: [9.7709, 125.4934] },
  { id: 'punta_bilar', name: 'Punta Bilar', center: [9.7963, 125.4975] },
  { id: 'ipil', name: 'Ipil', center: [9.7649, 125.4861] },
  { id: 'cagniog', name: 'Cagniog', center: [9.8025, 125.4812] },
  { id: 'quezon', name: 'Quezon', center: [9.7795, 125.4835] },
];

function matchBarangay(text = '') {
  const lower = text.toLowerCase();
  return BARANGAYS.find((b) => lower.includes(b.name.toLowerCase())) ?? null;
}

exports.pollFacebookPage = onSchedule(
  {
    schedule: 'every 1 minutes',
    secrets: [PAGE_ACCESS_TOKEN],
    timeoutSeconds: 30,
  },
  async () => {
    const db = getDatabase();
    const metaRef = db.ref('_meta/lastFacebookPoll');
    const since = (await metaRef.get()).val() || Math.floor(Date.now() / 1000) - 300;

    const url = new URL(`https://graph.facebook.com/v21.0/${PAGE_ID.value()}/feed`);
    url.searchParams.set('fields', 'message,created_time,permalink_url,comments{message,created_time}');
    url.searchParams.set('since', String(since));
    url.searchParams.set('access_token', PAGE_ACCESS_TOKEN.value());

    const res = await fetch(url);
    const body = await res.json();
    if (!res.ok) {
      console.error('[pollFacebookPage] Graph API error', body?.error ?? body);
      return;
    }

    const reportsRef = db.ref('reports');
    const leadsRef = db.ref('facebookLeads');
    let newest = since;

    for (const post of body.data ?? []) {
      const postTime = Math.floor(new Date(post.created_time).getTime() / 1000);
      newest = Math.max(newest, postTime);

      const candidates = [
        { text: post.message, id: post.id },
        ...((post.comments?.data) ?? []).map((c) => ({ text: c.message, id: c.id })),
      ];

      for (const c of candidates) {
        if (!c.text || !mentionsFire(c.text)) continue;

        const barangay = matchBarangay(c.text);
        const reportedAt = new Date(postTime * 1000).toISOString();
        const note = c.text.slice(0, 280);

        if (barangay) {
          // Located — enters the normal pipeline. On its own this scores
          // below the auto-post threshold (text only, no image), so it
          // shows as a Light Warning until something corroborates it: a
          // second Facebook mention, an app report, or the aerial sweep.
          await reportsRef.child(`fb-${c.id}`).set({
            id: `fb-${c.id}`,
            location: barangay.center,
            barangayId: barangay.id,
            source: 'facebook',
            modelConfidence: 0.55,
            note,
            driveUrl: null,
            reportedAt,
          });
        } else {
          // No barangay named in the text — can't be plotted, so it waits
          // here for a person to add a location rather than guessing one.
          // This queue is intel, not an approval gate: it never blocks or
          // delays anything already in the located pipeline above.
          await leadsRef.child(`fb-${c.id}`).set({ id: `fb-${c.id}`, note, reportedAt });
        }
      }
    }

    await metaRef.set(newest + 1);
  }
);

// Keep the PM2.5 corroboration poll separate from Facebook, while re-exporting
// it here because Firebase loads this file as the functions package entrypoint.
exports.pollAirQuality = require('./airQuality').pollAirQuality;
