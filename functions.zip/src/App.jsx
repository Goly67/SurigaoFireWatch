import { useCallback, useEffect, useMemo, useState } from 'react';
import MapView from './components/MapView.jsx';
import Sidebar from './components/Sidebar.jsx';
import ReportForm from './components/ReportForm.jsx';
import IncidentPanel from './components/IncidentPanel.jsx';
import WarningSystem from './components/WarningSystem.jsx';
import Timeline from './components/Timeline.jsx';
import NotificationCenter from './components/NotificationCenter.jsx';
import { HazePanel, HazeTimeline, HazeToggle, useHaze } from './components/HazeUI.jsx';
import { buildIncidents } from './lib/incidents.js';
import { fetchWind, FALLBACK_WIND } from './lib/wind.js';
import {
  subscribeToReports, addReport, usingFirebase, subscribeToFacebookLeads, dismissFacebookLead,
  subscribeToAirQualitySignals, subscribeToPostApprovals, approveForPost, revokePostApproval,
} from './lib/reportsStore.js';

// Wind and the Indonesia haze forecast both refresh on this cadence.
const REFRESH_MS = 2 * 60 * 1000;

export default function App() {
  const [reports, setReports] = useState([]);
  const [facebookLeads, setFacebookLeads] = useState([]);
  const [airQualitySignals, setAirQualitySignals] = useState([]);
  const [postApprovals, setPostApprovals] = useState({});
  const [wind, setWind] = useState(FALLBACK_WIND);
  const [selectedId, setSelectedId] = useState(null);
  const [view, setView] = useState('list'); // list | report | levels
  const [pendingLocation, setPendingLocation] = useState(null);
  const [horizonMinutes, setHorizonMinutes] = useState(30);
  const [showStations, setShowStations] = useState(true);
  const [railOpen, setRailOpen] = useState(true);
  const [tick, setTick] = useState(0);
  const [draftFromLead, setDraftFromLead] = useState(null);
  const [hazeOn, setHazeOn] = useState(false); // haze is a map layer, not a separate mode
  const [hazeFrame, setHazeFrame] = useState(0); // 0..24, 3 h apart
  const [hazeFocus, setHazeFocus] = useState(null);

  const haze = useHaze(hazeOn);

  // Firebase Realtime Database when configured, in-memory sample data
  // otherwise — reportsStore.js hides which one this is.
  useEffect(() => subscribeToReports(setReports), []);
  useEffect(() => subscribeToFacebookLeads(setFacebookLeads), []);
  useEffect(() => subscribeToAirQualitySignals(setAirQualitySignals), []);
  useEffect(() => subscribeToPostApprovals(setPostApprovals), []);

  useEffect(() => {
    let cancelled = false;
    fetchWind().then((w) => !cancelled && setWind(w));
    const id = setInterval(() => {
      fetchWind().then((w) => !cancelled && setWind(w));
    }, REFRESH_MS);
    return () => {
      cancelled = true;
      clearInterval(id);
    };
  }, []);

  // Elapsed time feeds escalation, so recompute on a timer.
  useEffect(() => {
    const id = setInterval(() => setTick((t) => t + 1), 60 * 1000);
    return () => clearInterval(id);
  }, []);

  const incidents = useMemo(
    () => buildIncidents(reports, wind, airQualitySignals),
    [reports, wind, airQualitySignals, tick]
  );
  const airQualityActive = airQualitySignals.some((signal) => {
    const detectedAt = new Date(signal.detectedAt).getTime();
    return Number.isFinite(detectedAt) && Date.now() - detectedAt <= 30 * 60 * 1000;
  });
  const selected = incidents.find((i) => i.id === selectedId) ?? null;

  // 'confirmed' means 2+ independent reports already agree — that
  // corroboration is itself the safety check, so these post without
  // waiting on an admin. Only single-source 'unverified' incidents need a
  // person to click Approve (see IncidentPanel). Runs whenever the
  // incident list changes; skips anything already recorded either way.
  useEffect(() => {
    for (const incident of incidents) {
      if (
        incident.triage.status === 'confirmed' &&
        incident.triage.autoPost &&
        !(incident.id in postApprovals)
      ) {
        approveForPost(incident.id, 'auto-corroborated');
      }
    }
  }, [incidents, postApprovals]);

  const changeHorizon = useCallback((next) => {
    setHorizonMinutes((prev) => (typeof next === 'function' ? next(prev) : next));
  }, []);

  // Passed down into MapView -> the memoized LocalLayer (see MapView.jsx).
  // An inline arrow here would get a new reference every render — including
  // every haze-timeline tick — which would defeat that memoization and
  // force every fire pin to re-render for no reason.
  const selectIncident = useCallback((id) => {
    setView('list');
    setSelectedId(id);
    setHorizonMinutes(30);
  }, []);

  function submitReport(report) {
    addReport(report);
    setView('list');
    setPendingLocation(null);
    setDraftFromLead(null);
    setSelectedId(report.id);
    setHorizonMinutes(30);
  }

  function placeLeadOnMap(lead) {
    setDraftFromLead({ note: lead.note, source: 'facebook' });
    dismissFacebookLead(lead.id);
    setView('report');
    setSelectedId(null);
  }

  function reportExistingFire(location) {
    setPendingLocation([...location]);
    setDraftFromLead(null);
    setView('report');
    setSelectedId(null);
  }

  function toggleHaze(on) {
    setHazeOn(on);
    setShowStations(!on);
    if (on) {
      setView('list');
      setSelectedId(null);
      setPendingLocation(null);
      setDraftFromLead(null);
      setRailOpen(true);
    }
  }

  const reporting = !hazeOn && view === 'report';

  let rail;
  if (hazeOn) {
    rail = <HazePanel haze={haze} frame={hazeFrame} onFocus={(c) => setHazeFocus([...c])} />;
  } else if (reporting) {
    rail = (
      <ReportForm
        location={pendingLocation}
        incidents={incidents}
        onPlaceRequest={setPendingLocation}
        onSubmit={submitReport}
        prefill={draftFromLead}
        onCancel={() => {
          setView('list');
          setPendingLocation(null);
          setDraftFromLead(null);
        }}
      />
    );
  } else if (view === 'levels') {
    rail = (
      <WarningSystem
        activeLevel={selected ? selected.alarm.level : null}
        onClose={() => setView('list')}
      />
    );
  } else if (selected) {
    rail = (
      <IncidentPanel
        incident={selected}
        horizonMinutes={horizonMinutes}
        onBack={() => setSelectedId(null)}
        onOpenLevels={() => setView('levels')}
        postApproval={postApprovals[selected.id] ?? null}
        onApprovePost={() => approveForPost(selected.id)}
        onRevokePost={() => revokePostApproval(selected.id)}
        onReportFire={reportExistingFire}
      />
    );
  } else {
    rail = (
      <Sidebar
        incidents={incidents}
        wind={wind}
        selectedId={selectedId}
        showStations={showStations}
        onToggleStations={() => setShowStations((s) => !s)}
        onSelect={setSelectedId}
        facebookLeads={facebookLeads}
        airQualityActive={airQualityActive}
        onPlaceLead={placeLeadOnMap}
        onDismissLead={dismissFacebookLead}
        onReport={() => {
          setView('report');
          setSelectedId(null);
        }}
        onOpenLevels={() => setView('levels')}
      />
    );
  }

  return (
    <div className={`app ${railOpen ? '' : 'rail-collapsed'}`}>
      <aside className="rail" key={hazeOn ? 'haze' : reporting ? 'report' : view + (selectedId ?? '')}>
        {rail}
      </aside>

      <button
        className="rail-handle"
        onClick={() => setRailOpen((o) => !o)}
        aria-expanded={railOpen}
        aria-label={railOpen ? 'Hide panel' : 'Show panel'}
        title={railOpen ? 'Hide panel' : 'Show panel'}
      >
        <span className="rail-handle-arrow" />
      </button>

      <main className="stage">
        <HazeToggle on={hazeOn} onChange={toggleHaze} />

        <NotificationCenter
          incidents={incidents}
          onSelect={(id) => {
            setHazeOn(false);
            setView('list');
            setSelectedId(id);
            setHorizonMinutes(30);
            setRailOpen(true);
          }}
        />

        {!usingFirebase && !hazeOn && (
          <div className="db-flag" title="Copy .env.example to .env.local with your Firebase project to go live">
            Sample data — connect Firebase to go live
          </div>
        )}

        <MapView
          incidents={incidents}
          selectedId={selectedId}
          onSelect={selectIncident}
          placing={reporting}
          pendingLocation={pendingLocation}
          onPickLocation={setPendingLocation}
          horizonMinutes={horizonMinutes}
          showStations={showStations}
          railOpen={railOpen}
          hazeMode={hazeOn}
          haze={haze.data}
          hazeFrame={hazeFrame}
          hazeFocus={hazeFocus}
        />

        {reporting && <div className="map-hint">Tap the map where the fire is</div>}

        {hazeOn && haze.data?.frames && (
          <HazeTimeline frame={hazeFrame} onChange={setHazeFrame} baseTime={haze.data.baseTime} />
        )}

        {!hazeOn && selected && selected.alarm.level > 0 && !reporting && (
          <Timeline
            minutes={horizonMinutes}
            onChange={changeHorizon}
            alarmColor={selected.alarm.color}
          />
        )}
      </main>
    </div>
  );
}